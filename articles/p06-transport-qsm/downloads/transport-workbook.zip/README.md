# m3-transport-policy 离线练习包

1. 在已有 Python 环境安装依赖：`python -X utf8 -m pip install -r requirements.txt`。
2. 如环境尚无 Jupyter，安装 `jupyterlab`，然后执行 `jupyter lab`。
3. 打开 `transport.ipynb`，重启内核并从头执行。保留 Notebook 与 data/ 的相对位置。

代码包含全部模型函数；模型计算不需要联网。课程与文献外链需要网络。
数据为教学构造。参考结果用于对照，不作为计算输入。
网页中的公式和图形编号由 Quarto 生成；Jupyter 主要用于运行与修改参数。
