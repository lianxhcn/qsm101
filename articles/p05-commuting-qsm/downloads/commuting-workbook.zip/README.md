# 通勤模型离线练习包

全部数值是教学构造，不代表真实城市。网页和本包 Notebook 同源，无作者署名。

1. 解压全部文件，保持 commuting.ipynb 与 data/ 在同一目录。
2. 在项目专用 Python 环境中提前运行 `python -m pip install -r requirements.txt`。
3. 运行 `python -m jupyterlab commuting.ipynb`，选择该 Python 内核，从头运行全部单元。

依赖安装完成后，计算只读取本地 CSV，不需要联网，不需要参考脚本。中文绘图需要 Microsoft YaHei、SimHei 或 Noto Sans CJK SC。若字体缺失，按报错配置字体后重跑绘图格；不要据此修改数据。

每个输入均检查 SHA256。不要用随机生成数据替换缺失文件。含 42 个单元、21 个代码单元和 5 张图；方程与情景核验共 484 项，另有样本再生与练习核对。原网页输出已经保留，方便运行前阅读。

文中的模型说明、参考资料和网页链接需要网络或完整仓库，本包执行不依赖这些外部文件。主政策使用教学真值，模拟估计值用于指定敏感性情景；福利不包含建设成本或财政支出。

在线章节：https://lianxhcn.github.io/qsm101/site/pages/commuting.html
代码与课程内容分别遵循附带 LICENSE-CODE 与 LICENSE-CONTENT.md。
